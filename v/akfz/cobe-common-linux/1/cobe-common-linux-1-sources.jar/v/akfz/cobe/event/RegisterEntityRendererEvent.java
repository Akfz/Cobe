package v.akfz.cobe.event;

import v.akfz.aslib.event.api.Event;
import v.akfz.cobe.util.EntityRendererData;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;

public class RegisterEntityRendererEvent extends Event {
    private final List<EntityRendererData> registrars = new ArrayList<>();

    public <T extends class_1297> void register(class_1299<T> entityType, class_5617<T> entityRendererProvider) {
        this.registrars.add(new EntityRendererData(entityType, entityRendererProvider));
    }

    public List<EntityRendererData> getRegistrars() {
        return this.registrars;
    }
}
