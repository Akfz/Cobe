package v.akfz.cobe.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import v.akfz.cobe.core.animation.AsyncAnimationEngine;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    public void cobe$tick(CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && !AsyncAnimationEngine.getInstance().isRunning()) {
            AsyncAnimationEngine.getInstance().start();
        }
    }

    @Inject(method = "clearLevel(Lnet/minecraft/client/gui/screens/Screen;)V", at = @At("HEAD"))
    private void cobe$onClearLevel(class_437 screen, CallbackInfo ci) {
        /*
        if (!AnimationCache.getFromCacheAnimation().isEmpty()) {
            AnimationCache.cleanCacheAnimations();
        }
         */
        if (AsyncAnimationEngine.getInstance().isRunning()) {
            AsyncAnimationEngine.getInstance().stop();
        }
    }
}
