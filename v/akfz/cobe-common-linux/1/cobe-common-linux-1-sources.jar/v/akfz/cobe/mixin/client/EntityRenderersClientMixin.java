package v.akfz.cobe.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import v.akfz.aslib.AsLib;
import v.akfz.cobe.event.RegisterEntityRendererEvent;
import v.akfz.cobe.util.EntityRendererData;

import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;
import net.minecraft.class_5619;
import net.minecraft.class_897;

@Mixin(class_5619.class)
public class EntityRenderersClientMixin {

    @Shadow
    public static <T extends class_1297> void register(class_1299<? extends T> entityType, class_5617<T> entityRendererProvider) {
        throw new IllegalStateException("Mixin not applied");
    }

    @Inject(method = "createEntityRenderers", at = @At("HEAD"))
    private static void cobe$registerEntityRenderers(
            class_5617.class_5618 context,
            CallbackInfoReturnable<Map<class_1299<?>, class_897<?>>> cir
    ) {
        RegisterEntityRendererEvent event = new RegisterEntityRendererEvent();
        AsLib.EVENT_BUS.post(event);
        event.getRegistrars().forEach(EntityRenderersClientMixin::cobe$helperRegister);
    }

    @SuppressWarnings("unchecked")
    private static <E extends class_1297> void cobe$helperRegister(EntityRendererData data) {
        class_1299<E> type = (class_1299<E>) data.entityType();
        class_5617<E> provider = (class_5617<E>) data.entityRendererProvider();
        register(type, provider);
    }
}