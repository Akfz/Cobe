package v.akfz.cobe.texture;

import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.class_1044;
import net.minecraft.class_276;
import net.minecraft.class_3300;

//передавать готовый буффер
public class RenderTargetTexture extends class_1044 {
	private final class_276 renderTarget;

	public RenderTargetTexture(class_276 renderTarget) {
		this.renderTarget = renderTarget;
	}

	@Override
	public void method_4625(class_3300 resourceManager) {
	}

	@Override
	public void method_23207() {
		GlStateManager._bindTexture(this.renderTarget.method_30277());
	}

	@Override
	public int method_4624() {
		return this.renderTarget.method_30277();
	}

	@Override
	public void close() {
		super.close();
		if (this.renderTarget != null) {
			this.renderTarget.method_1238();
		}
	}
}
