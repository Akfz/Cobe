package v.akfz.cobe.util;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;

public record EntityRendererData(class_1299<? extends class_1297> entityType, class_5617<? extends class_1297> entityRendererProvider) {}
