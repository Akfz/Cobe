package v.akfz.cobe.texture.video;

import v.akfz.cobe.core.render.DefaultCobeRenderer;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2960;

public class VideoPlayerManager {
    private static final VideoPlayerManager INSTANCE = new VideoPlayerManager();
    public static VideoPlayerManager getInstance() { return INSTANCE; }

    private final Map<String, VideoStreamPlayer> activePlayers = new ConcurrentHashMap<>();

    private VideoPlayerManager() {}

    public class_2960 getOrCreatePlayer(File file, boolean loop, Runnable onFinished) {
        String key = "file_" + file.getAbsolutePath();
        VideoStreamPlayer player = activePlayers.computeIfAbsent(key, path -> {
            VideoStreamPlayer p = new VideoStreamPlayer(file, loop, onFinished);
            p.start();
            return p;
        });
        return player.getTextureLocation();
    }

    public class_2960 getOrCreatePlayer(class_2960 resourceLocation, boolean loop, Runnable onFinished) {
        String key = "rl_" + resourceLocation.toString();
        VideoStreamPlayer player = activePlayers.computeIfAbsent(key, path -> {
            VideoStreamPlayer p = new VideoStreamPlayer(resourceLocation, loop, onFinished);
            p.start();
            return p;
        });
        return player.getTextureLocation();
    }

    public class_2960 getOrCreatePlayer(String relativePath, boolean loop, Runnable onFinished) {
        if (relativePath.contains(":")) {
            return getOrCreatePlayer(new class_2960(relativePath), loop, onFinished);
        } else {
            return getOrCreatePlayer(new class_2960("cobe", relativePath), loop, onFinished);
        }
    }

    public void stopAndRelease(String key) {
        VideoStreamPlayer player = activePlayers.remove(key);
        if (player != null) {
            player.stop();
        }
    }

    public void stopAll() {
        for (String key : activePlayers.keySet()) {
            stopAndRelease(key);
        }
    }
}