package v.akfz.cobe.test;

import net.minecraft.class_1299;
import net.minecraft.class_1311;
import v.akfz.aslib.AsLib;
import v.akfz.aslib.annotation.RegisterModule;
import v.akfz.aslib.initializer.generator.GenerateRegistries;import v.akfz.aslib.registry.RegistryHelper;

@GenerateRegistries(modId = "cobe")
public class CobeRegistries {
    @RegisterModule(id = "cobe:testentity")
    public static class_1299<TestEntity> TEST_ENTITY = RegistryHelper.createEntity(TestEntity::new,class_1311.field_17715,1f,1f,"cobe:testentity");
}
