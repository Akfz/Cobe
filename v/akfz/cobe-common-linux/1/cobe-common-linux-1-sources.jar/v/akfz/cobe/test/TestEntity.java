package v.akfz.cobe.test;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;
import v.akfz.cobe.core.animation.AnimationController;
import v.akfz.cobe.core.animation.AsyncAnimationEngine;
import v.akfz.cobe.core.cache.AnimatedObjectCache;
import v.akfz.cobe.core.object.AnimatedObject;

public class TestEntity extends class_1297 implements AnimatedObject {
    private final AnimationController controller = new AnimationController(this);
    private final AnimatedObjectCache cache = new AnimatedObjectCache();

    public TestEntity(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
        fastInit();
        this.getController().play("baked_animation", true);
    }

    @Override
    public void method_5650(@NotNull class_5529 reason) {
        super.method_5650(reason);
        AsyncAnimationEngine.getInstance().unregister(this.getStrId());
    }

    @Override
    protected void method_5693() {}

    @Override
    protected void method_5749(class_2487 compound) {}

    @Override
    protected void method_5652(class_2487 compound) {}

    @Override
    public String getStrId() {
        return "test" + this.method_5628();
    }

    @Override
    public AnimationController getController() {
        return controller;
    }

    @Override
    public AnimatedObjectCache getCache() {
        return cache;
    }

    @Override
    public class_243 getPos() {
        return super.method_30950(0);
    }
}