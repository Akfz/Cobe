package v.akfz.cobe.test;

import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import v.akfz.cobe.core.render.DefaultCobeRenderer;
import v.akfz.cobe.texture.video.VideoPlayerManager;
import v.akfz.cobe.texture.video.VideoTexture;

public class TestEntityRenderer extends class_897<TestEntity> implements DefaultCobeRenderer<TestEntity> {
    private final int type = 0; //0 - null, 1 - video 2 - buffer

    public TestEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public void render(TestEntity entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight) {
        defaultRender(poseStack, entity, buffer, null, null, partialTick, packedLight);
    }
    @Override
	public class_2960 getTextureLocation(TestEntity entity) {
		return null;
	}
/*
    @Override
    public boolean shouldForceFullUV(String boneName) {
        return type == 0;
    }

    @Override
    public ResourceLocation getBoneTextureOverride(String boneName) {
        if (type == 1) {
            return VideoPlayerManager.getInstance().getOrCreatePlayer(new ResourceLocation("eww", "test/video.mp4"), true, () -> {});
        } else if (type == 2){
            return null;
        } else {
            return DefaultCobeRenderer.super.getBoneTextureOverride(boneName);
        }
    }
 */

    @Override
    public String getNameOfModel() {
        return "CobeModel";
    }
}