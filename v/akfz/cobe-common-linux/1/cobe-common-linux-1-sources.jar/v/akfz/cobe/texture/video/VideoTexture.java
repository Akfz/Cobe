package v.akfz.cobe.texture.video;

import java.util.UUID;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * How to use : VideoPlayerManager.getInstance().getOrCreatePlayer("textures/siuu.mp4", true, () -> {});
 */
public class VideoTexture extends class_1043 {
    private final class_2960 location;
    private final class_1011 backgroundBuffer;
    private final Object lock = new Object();
    private volatile boolean hasNewFrame = false;

    public VideoTexture(int width, int height) {
        super(width, height, true);
        this.backgroundBuffer = new class_1011(width, height, false);
        this.location = new class_2960("cobe_video", "video_" + UUID.randomUUID().toString().replace("-", "_"));
        class_310.method_1551().method_1531().method_4616(this.location, this);
    }

    public void writePixels(java.nio.IntBuffer intBuf, int width, int height) {
        synchronized (lock) {
            for (int y = 0; y < height; y++) {
                int rowOffset = y * width;
                for (int x = 0; x < width; x++) {
                    int abgr = intBuf.get(rowOffset + x);

                    int destX = width - 1 - x;
                    backgroundBuffer.method_4305(destX, y, abgr);
                }
            }
            hasNewFrame = true;
        }
    }

    public void uploadFrame() {
        if (!hasNewFrame) return;

        class_310 mc = class_310.method_1551();
        if (!mc.method_18854()) return;

        synchronized (lock) {
            class_1011 internalPixels = this.method_4525();
            if (internalPixels != null) {
                internalPixels.method_4317(backgroundBuffer);
                this.method_4524();
            }
            hasNewFrame = false;
        }
    }

    @Override
    public void close() {
        super.close();
        backgroundBuffer.close();
    }

    public class_2960 getLocation() {
        return this.location;
    }
}