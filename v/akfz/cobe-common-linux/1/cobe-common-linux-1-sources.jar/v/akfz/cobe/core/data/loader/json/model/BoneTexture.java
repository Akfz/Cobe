package v.akfz.cobe.core.data.loader.json.model;

import com.google.gson.annotations.SerializedName;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class BoneTexture {
    @SerializedName("nameBone")
    private final String bone;

    @SerializedName("location")
    private final String loc;

    public BoneTexture(String nameBone, String location) {
        this.bone = nameBone;
        this.loc = location != null ? location : "";
    }

    public String getBone() {
        return bone;
    }

    public boolean locIsRl() {
        return !loc.startsWith("/");
    }

    @Nullable
    public class_2960 getRl() {
        if (!locIsRl()) {
            return null;
        }
        return class_2960.method_12829(loc);
    }

    @Nullable
    public Path getPath() {
        if (locIsRl()) {
            return null;
        }
        String relativeLoc = loc.startsWith("/") ? loc.substring(1) : loc;
        return class_310.method_1551().field_1697.toPath().resolve(relativeLoc);
    }
}
